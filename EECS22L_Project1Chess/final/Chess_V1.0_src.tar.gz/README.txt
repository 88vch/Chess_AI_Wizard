Author:  Tommy Kung, Kunal Paode, Zachary Qin, Angelica Miranda Luna, Jeffrey Yu 

Version: 1.0

Date: April 24, 2022

Instructions: 
    To install and uninstall the program follow the instructions in the INSTALL file
    To find the rules about the game of chess and general instructions, follow the User Manual
    
     For AI
    Please press the AI
    Choose which side
    TO activate the ai please press the Ai pieces twice
    Ex. Player is White Ai is Black
        Player presses the black pieces twice
        Ai would move