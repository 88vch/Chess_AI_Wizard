#ifndef CHESS_H_
#define CHESS_H_
#include "Board.h"

int *MovePieces(int oldmove[2], int newmove[2], Board *subBoard);//position board

#endif