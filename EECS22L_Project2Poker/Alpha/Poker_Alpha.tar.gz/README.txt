Author:  Tommy Kung, Kunal Paode, Zachary Qin, Chenhao Yang, Jeffrey Yu

Version: 1.0

Date: May 22, 2022

Instructions:
    To install, uninstall, and run the program follow the instructions in the INSTALL file
    To find the rules about the game of poker and general instructions, follow the User Manual