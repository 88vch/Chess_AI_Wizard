Author:  Tommy Kung, Kunal Paode, Zachary Qin, Chenhao Yang, Jeffrey Yu

Version: 1.0

Date: June 6, 2022

Instructions:
    To install, uninstall, and run the program follow the instructions in the INSTALL file
    To find the rules about the game of poker and general instructions, follow the User Manual

General Instructions:
    Click settings to enter number of players and player position'
    Click start to start the game
    When the box turns green, it signals that it is your turn
    Choose your move(Fold, Raise, Check, Call)
    For raise, enter your amount and click the raise button
    Click send to confirm the move
    Click redo to reselect your move
    Wait for box to turn green to move again'
    If you do not see your cards on your turn, Click the update button
